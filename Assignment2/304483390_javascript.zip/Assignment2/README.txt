John Storch
304483390

Assignment 2 README

My animation show a 100 meter dash with 7 competitors in front of a large crowd in a stadium. 
The winner is crowned at the very end.

My hierachical objects are the runners as they it goes drawPerson and inside that function there is drawArm
and drawLegs. Also the Stadium is a hierachial object as it is drawTrack and has the drawCurvedLines function.
Finally, drawStatium has the drawStadiumPillars inside of it.

The polygonal object is a square piramid and its located on top of the pillar (it is suppose to be fire).

My scene has two textures, one is the piramids which have a fire texture on them. The other is the stands
which have a crowd like texture on them.

