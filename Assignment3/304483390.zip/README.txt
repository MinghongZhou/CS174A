John Storch
304483390

My raytracer code passes all required test cases.
(testIllum.txt was said to not count on piazza so I assume that test doesnt't matter)